const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('capstone_db', 'valentin_user', 'valecoria', {
  host: '127.0.0.1',
  dialect: 'mysql',
 // logging: false, // opcional, para que no muestre logs SQL en consola
});

const testConnection = async () => {
  try {
    await sequelize.authenticate();
    console.log('Conexión a la base de datos establecida correctamente.✅ ');
  } catch (error) {
    console.error('No se pudo conectar a la base de datos:❌ ', error);
  }
};

testConnection();

module.exports = sequelize;
