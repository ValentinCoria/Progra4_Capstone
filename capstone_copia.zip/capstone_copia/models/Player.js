const {DataTypes} = require('sequelize');
const sequelize = require('../config/db')

const Player = sequelize.define('Player',
    {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    nickname: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    email: {
        type: DataTypes.STRING,
        unique: true,
    },
    age: {
        type: DataTypes.INTEGER,
    },
},
    {
        timestamps: true,
        tableName: 'players'
    }
);

module.exports = Player;