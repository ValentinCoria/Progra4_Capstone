const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Game = sequelize.define('Game', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  status: {
    type: DataTypes.STRING,
  },
  maxPlayers: {
    type: DataTypes.INTEGER,
  },
}, {
  timestamps: true,   // para que agregue createdAt y updatedAt
  tableName: 'games',
});

module.exports = Game;
