const errorHandler = (err, req, res, next) => {
  console.error(err.stack); // ver el error en consola
  res.status(500).json({
    message: 'Error!',
    error: err.message,
  });
};

module.exports = errorHandler;
