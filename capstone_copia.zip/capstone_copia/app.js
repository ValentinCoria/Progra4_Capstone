const express = require('express');
const app = express();
const port = 3000;

// Middlewares
const logger = require('./middleware/logger');
const errorHandler = require('./middleware/errorHandler');

// Rutas
const playerRoutes = require('./routes/player.routes'); 
const gameRoutes = require('./routes/game.routes');
const cardRoutes = require('./routes/card.routes');
const scoreRoutes = require('./routes/score.routes');

// Base de datos
const sequelize = require('./config/db');

// 🟢 Middleware para parsear JSON antes de cualquier ruta
app.use(express.json());

// 🟢 Middleware personalizado de log
app.use(logger);

// 🟢 Rutas de la API 
app.use('/api/players', playerRoutes); 
app.use('/api/games', gameRoutes); 
app.use('/api/cards', cardRoutes);
app.use('/api/scores', scoreRoutes);

// 🔴 Middleware de manejo de errores (último siempre)
app.use(errorHandler);

// Sincronizar DB y arrancar servidor
sequelize.sync({ force: false }) // force: true borra y recrea tabla
  .then(() => {
    console.log('Tabla Games sincronizada correctamente');
    app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
    });
  })
  .catch(err => {
    console.log('Error sincronizando tabla:', err);
  });
