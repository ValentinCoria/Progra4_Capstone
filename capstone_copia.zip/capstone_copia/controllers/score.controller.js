const Score = require('../models/Score');

const createScore = async (req, res, next) => {
  try {
    const newScore = await Score.create(req.body);
    res.status(201).json(newScore);
  } catch (error) {
    next(error);
  }
};

const getAllScores = async (req, res, next) => {
  try {
    const allScores = await Score.findAll();
    res.json(allScores);
  } catch (error) {
    next (error);
  }  
}

const getScoreById = async (req, res, next) => {
  try {
    const score = await Score.findByPk(req.params.id);
    if (!score) return res.status(404).json({ message: 'Score not found' });
    res.json(score);
  } catch (error) {
    next(error);
  }
};

const updateScore = async (req, res, next) => {
  try {
    const [updated] = await Score.update(req.body, {
      where: { id: req.params.id }
    });
    if (!updated) return res.status(404).json({ message: 'Score not found' });
    const updatedScore = await Score.findByPk(req.params.id);
    res.json(updatedScore);
  } catch (error) {
    next(error);
  }
};

const deleteScore = async (req, res, next) => {
  try {
    const deleted = await Score.destroy({
      where: { id: req.params.id }
    });
    if (!deleted) return res.status(404).json({ message: 'Score not found' });
    res.status(204).send();
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createScore,
  getAllScores,
  getScoreById,
  updateScore,
  deleteScore
};
