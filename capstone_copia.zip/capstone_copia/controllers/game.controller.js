const Game = require('../models/Game');

const createGame = async (req, res, next) => {
  try {
    const newGame = await Game.create(req.body);
    res.status(201).json(newGame);
  } catch (error) {
    next(error);
  }
};

const getAllGames = async (req, res, next) => {
    try {
        const allGames = await Game.findAll();
        res.json(allGames);
    } catch (error) {
        next(error);
    }
};

const getGameById = async (req, res, next) => {
  try {
    const game = await Game.findByPk(req.params.id);
    if (!game) return res.status(404).json({ message: 'Game not found' });
    res.json(game);
  } catch (error) {
    next(error);
  }
};

const updateGame = async (req, res, next) => {
  try {
    const [updated] = await Game.update(req.body, {
      where: { id: req.params.id }
    });
    if (!updated) return res.status(404).json({ message: 'Game not found' });
    const updatedGame = await Game.findByPk(req.params.id);
    res.json(updatedGame);
  } catch (error) {
    next(error);
  }
};

const deleteGame = async (req, res, next) => {
  try {
    const deleted = await Game.destroy({
      where: { id: req.params.id }
    });
    if (!deleted) return res.status(404).json({ message: 'Game not found' });
    res.status(204).send();
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createGame,
  getAllGames,
  getGameById,
  updateGame,
  deleteGame,
};
