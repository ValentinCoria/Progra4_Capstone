const Card = require('../models/Card');

const createCard = async (req, res, next) => {
  try {
    const newCard = await Card.create(req.body);
    res.status(201).json(newCard);
  } catch (error) {
    next(error);
  }
};

const getAllCards = async (req, res, next) => {
  try {
    const allCards = await Card.findAll();
    res.json(allCards);
  } catch (error) {
    next(error);
  }
}

const getCardById = async (req, res, next) => {
  try {
    const card = await Card.findByPk(req.params.id);
    if (!card) return res.status(404).json({ message: 'Card not found' });
    res.json(card);
  } catch (error) {
    next(error);
  }
};

const updateCard = async (req, res, next) => {
  try {
    const [updated] = await Card.update(req.body, {
      where: { id: req.params.id }
    });
    if (!updated) return res.status(404).json({ message: 'Card not found' });
    const updatedCard = await Card.findByPk(req.params.id);
    res.json(updatedCard);
  } catch (error) {
    next(error);
  }
};

const deleteCard = async (req, res, next) => {
  try {
    const deleted = await Card.destroy({
      where: { id: req.params.id }
    });
    if (!deleted) return res.status(404).json({ message: 'Card not found' });
    res.status(204).send();
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createCard,
  getAllCards,
  getCardById,
  updateCard,
  deleteCard
};
