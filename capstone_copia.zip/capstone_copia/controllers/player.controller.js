const Player = require('../models/Player');

//Get all players

const getPlayers = async(req, res, next) => {
    try {
        const players = await Player.findAll();
        res.json(players);
    } catch (error) {
        next(error);
    }
};

//Get one player by it ID
const getPlayerById = async(req, res, next) => {
    try {
        const player = await Player.findByPk(req.params.id);
        if (player) {
            res.json(player);
        } else {
            res.status(404).json({message: 'player not found'});
        }
    } catch (error) {
        next(error);
        
    }
};

// POST create new player
const createPlayer = async(req, res, next) => {
    try {
        const newPlayer = await Player.create(req.body);
        res.status(201).json(newPlayer);
        
    } catch (error) {
        next(error);
        
    }
}

// PUT update player
const updatePlayer = async (req, res, next) => {
  try {
    const result = await Player.update(req.body, {
      where: { id: req.params.id }
    });

    if (result[0] === 1) {
      res.json({ message: 'Player updated' });
    } else {
      res.status(404).json({ message: 'Player not found or no changes' });
    }
  } catch (err) {
    next(err);
  }
};

// DELETE player
const deletePlayer = async (req, res, next) => {
    try {
        const result = await Player.destroy({
            where: {id: req.params.id}
        });
        if (result) {
            res.json({message: 'player deleted'})
        } else {
            res.status(404).json({message: 'player not found'});
        }
    } catch (error) {
        next(error);
    }
};

module.exports = {
    getPlayers,
    getPlayerById,
    createPlayer,
    updatePlayer,
    deletePlayer
};