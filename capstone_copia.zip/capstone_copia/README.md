# Capstone Task 1.4 – Node.js API con Express y Sequelize

Este proyecto forma parte del Capstone de la materia Programación 4. Se trata de una API simple construida con **Node.js**, **Express**, y **Sequelize** para interactuar con una base de datos MySQL. Se implementaron rutas básicas para simular operaciones CRUD.

---

## 🧱 Estructura del Proyecto

├── controllers/  
│ └── app.controllers.js  
├── middleware/  
│ ├── errorHandler.js  
│ └── logger.js  
├── models/  
│ └── Game.js  
├── routes/  
│ └── app.routes.js  
├── config/  
│ └── db.js  
├── app.js

---

##  Pruebas con Postman

Se encuentran en la descripcion del merge request.

## 🛢️ Base de Datos MySQL

Ejemplo de estructura de la tabla `games` generada por Sequelize:

```sql
CREATE TABLE games (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  genre VARCHAR(255),
  platform VARCHAR(255)
);
```

## Task 2.4 - Juego de Cartas UNO

Este proyecto es una API RESTful que simula una versión digital del juego de cartas UNO, permitiendo gestionar jugadores, partidas, cartas y puntuaciones utilizando una arquitectura de tres capas con Express.js y Sequelize ORM.

---

## 📌 Objetivos del Proyecto

1. **CRUD de Jugadores**
2. **CRUD de Juegos**
3. **CRUD de Cartas**
4. **CRUD de Scores históricos**
5. **Arquitectura de tres capas**
6. **Uso de ORM (Sequelize)**
7. **Uso de base de datos relacional (SQLite / PostgreSQL / MySQL)**
8. **Colección de Postman para pruebas**

---

Pruebas de Postman se encuentran en la descipcion del MR en gitlab, asi como el archivo **collection.json**